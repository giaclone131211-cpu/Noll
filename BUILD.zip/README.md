# Threads2Video 2.0

App Android biến bài Threads + bình luận thành video dọc 9:16 cho TikTok.

Mới ở bản 2.0:
- Dùng ảnh chụp màn hình bài viết và bình luận làm thẻ trong video (ảnh dài tự cuộn theo giọng đọc)
- Tự nhận diện avatar và tên, làm nhòe thành ô vuông (không khôi phục được), bạn xem lại và chỉnh từng ảnh trước khi dùng
- AI đọc chữ từ ảnh đã làm mờ để điền kịch bản (ChatGPT hoặc Gemini)
- Nhúng vieneu.io Studio vào app: sao chép từng đoạn kịch bản, tải file giọng, file tự vào danh sách
- Ký APK bằng khóa cố định, các bản sau cài đè không mất dữ liệu

Cấu trúc: vỏ Kotlin (app/src/main/java) + giao diện và lõi xử lý bằng web (app/src/main/assets/www).
Build bằng GitHub Actions (build.yml), ra file APK cài được ngay.

Mới ở bản 2.1:
- Research chủ đề: nhập chủ đề, app mở Threads (đăng nhập một lần), cuộn và xếp bài theo số tim, chọn một bài để tự điền bài gốc và các bình luận nhiều tim nhất
- Cào link nhanh: dán link bài Threads để lấy bài và bình luận
