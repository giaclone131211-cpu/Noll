package com.threads2video

import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

/** Kết quả quét Threads, MainActivity lấy khi quay lại. */
object ThreadsInbox {
    @Volatile var kind = ""
    @Volatile var json = ""
}

class ThreadsActivity : ComponentActivity() {

    private lateinit var web: WebView
    private lateinit var btn: Button
    private var mode = "search"
    private var count = 7

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "search"
        count = intent.getIntExtra("n", 7)
        val url = intent.getStringExtra("url") ?: "https://www.threads.com/"
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        val tip = TextView(this)
        tip.text = if (mode == "post") "Đợi bài và bình luận hiện ra, rồi bấm nút bên dưới."
        else "Đăng nhập Threads (chỉ lần đầu), đợi danh sách bài hiện ra rồi bấm nút bên dưới."
        tip.setTextColor(Color.WHITE)
        tip.setBackgroundColor(0xFF1B1B3A.toInt())
        tip.setPadding(24, 16, 24, 16)

        web = WebView(this)
        btn = Button(this)
        btn.text = if (mode == "post") "Lấy bài và bình luận" else "Quét bài hay"
        btn.setOnClickListener { scrape() }

        root.addView(tip, LinearLayout.LayoutParams(match, wrap))
        root.addView(web, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(btn, LinearLayout.LayoutParams(match, wrap))
        setContentView(root)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = web.settings.userAgentString.replace("; wv", "")
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(Sink(), "T2V")
        web.webViewClient = WebViewClient()
        web.loadUrl(url)
    }

    private fun scrape() {
        btn.isEnabled = false
        btn.text = "Đang quét, đợi vài giây…"
        val code = "(async function(){try{await (" + SCRAPE_JS + ")('" + mode + "'," + count + ")}catch(e){T2V.fail(String(e))}})()"
        web.evaluateJavascript(code, null)
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    inner class Sink {
        @JavascriptInterface
        fun done(json: String) {
            ThreadsInbox.kind = mode
            ThreadsInbox.json = json
            runOnUiThread { finish() }
        }

        @JavascriptInterface
        fun fail(msg: String) {
            runOnUiThread {
                Toast.makeText(this@ThreadsActivity, msg, Toast.LENGTH_LONG).show()
                btn.isEnabled = true
                btn.text = if (mode == "post") "Lấy bài và bình luận" else "Quét bài hay"
            }
        }
    }

    companion object {
        private const val SCRAPE_JS = """async function(mode, n) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const num = s => {
    let t = String(s || '').replace(/\s/g, '');
    if (/^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, '');
    const m = t.replace(',', '.').match(/^([\d.]+)(K|M|N|Tr)?$/i);
    if (!m) return -1;
    let v = parseFloat(m[1]); const u = (m[2] || '').toUpperCase();
    if (u === 'K' || u === 'N') v *= 1e3;
    if (u === 'M' || u === 'TR') v *= 1e6;
    return Math.round(v);
  };
  const ids = el => new Set(Array.from(el.querySelectorAll('a[href*="/post/"]')).map(x => (x.getAttribute('href').match(/\/post\/([\w-]+)/) || [])[1]).filter(Boolean));
  const timeRe = /^(\d+\s*(giây|phút|giờ|ngày|tuần|tháng|năm|s|m|h|d|w|y|min|hr|hrs)|vừa xong|\d{1,2}\/\d{1,2}(\/\d{2,4})?)$/i;
  const junk = /^(tác giả|author|theo dõi|follow|dịch|translate|xem hoạt động|view activity|đã xác minh|verified|·|\.\.\.|thêm|more|trả lời|reply)$/i;
  const grab = () => {
    const out = [], seen = new Set();
    document.querySelectorAll('a[href*="/post/"]').forEach(a => {
      const mm = (a.getAttribute('href') || '').match(/\/@([\w.]+)\/post\/([\w-]+)/);
      if (!mm || seen.has(mm[2])) return;
      let box = a;
      while (box.parentElement && ids(box.parentElement).size === 1 && box.parentElement.innerText.length < 3000) box = box.parentElement;
      const body = box.innerText.split('\n').map(x => x.trim()).filter(x => x && x !== mm[1] && x !== '@' + mm[1] && !timeRe.test(x) && !junk.test(x));
      const counts = [];
      while (body.length && num(body[body.length - 1]) >= 0) counts.unshift(num(body.pop()));
      const text = body.join(' ').replace(/\s+/g, ' ').trim();
      if (!text) return;
      seen.add(mm[2]);
      out.push({ id: mm[2], user: '@' + mm[1], text: text, likes: counts.length ? counts[0] : 0, url: 'https://www.threads.com/@' + mm[1] + '/post/' + mm[2] });
    });
    return out;
  };
  const rounds = mode === 'post' ? 4 : 7;
  for (let i = 0; i < rounds; i++) { window.scrollBy(0, window.innerHeight * 1.4); await sleep(1000); }
  const all = grab();
  if (!all.length) {
    T2V.fail(document.querySelector('input[type=password]') ? 'Hãy đăng nhập Threads trước rồi bấm lại' : 'Chưa thấy bài nào. Đợi trang tải xong rồi bấm lại');
    return;
  }
  if (mode === 'search') {
    const list = all.filter(p => p.text.length >= 40).sort((a, b) => b.likes - a.likes).slice(0, 15);
    T2V.done(JSON.stringify({ list: list }));
    return;
  }
  const mid = (location.pathname.match(/\/post\/([\w-]+)/) || [])[1];
  const post = all.find(p => p.id === mid) || all[0];
  const cms = all.filter(p => p !== post && p.user !== post.user).sort((a, b) => b.likes - a.likes).slice(0, n);
  T2V.done(JSON.stringify({ post: post, comments: cms }));
}
"""
    }
}
